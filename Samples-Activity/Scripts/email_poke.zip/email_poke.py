#! Python

import urllib.request
urllib.request.urlopen("https://aadsamplesactivity.azurewebsites.net/Home/SendMail").read()